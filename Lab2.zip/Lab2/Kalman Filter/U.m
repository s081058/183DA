function Ut = U(aL,aR)
Ut = [aL/360*2*pi*20;aR/360*2*pi*20];
end
