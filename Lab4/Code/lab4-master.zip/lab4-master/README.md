ECE 183DA-Lab1-Cowboy Team Minali Karapetian
